import json
from time import sleep
import requests
import xmltodict
import pymysql

db = pymysql.connect(host='database-1.c54q9v8pmtt2.us-east-2.rds.amazonaws.com', user='root', password='Nikhilk2kb2', database='ads')
cursor = db.cursor()

# print(cursor)


def comissionjun():
    n = 1
    try:
        init_data = get_data(n)
    except Exception as e:
        print(e)
        sleep(10)
        init_data = get_data(n)
    total_rec = int(init_data['cj-api']['advertisers']['@total-matched'])
    rec_return = int(init_data['cj-api']['advertisers']['@records-returned'])
    just_rec = rec_return
    if just_rec > 0:
        if len(init_data['cj-api']['advertisers']['advertiser']) > 0:
            for data in init_data['cj-api']['advertisers']['advertiser']:
                advertiser_id = data["advertiser-id"]
                advertiser_name = data['advertiser-name']
                program_url = data['program-url']
                commission = data['actions']['action']
                tracking_url = get_tracking_url(advertiser_id)
                final_commission = commission[0]['commission']['default'] if type(commission) == list else \
                    commission['commission']['default']
                if type(final_commission) == dict:
                    final_commission = final_commission['#text']

                try:
                    save_to_db(advertiser_id, advertiser_name, program_url, final_commission, tracking_url)
                except Exception as e:
                    print(advertiser_id, advertiser_name, program_url, final_commission)
                    print(e)
                    continue

        while just_rec < total_rec:
            n += 1

            cal_data = get_data(n)
            just_rec += int(cal_data['cj-api']['advertisers']['@records-returned'])
            if just_rec > 0:
                if len(cal_data['cj-api']['advertisers']['advertiser']) > 0:
                    for data in cal_data['cj-api']['advertisers']['advertiser']:
                        advertiser_id = data["advertiser-id"]
                        advertiser_name = data['advertiser-name']
                        program_url = data['program-url']
                        commission = data['actions']['action']
                        tracking_url = get_tracking_url(advertiser_id)

                        final_commission = commission[0]['commission']['default'] if type(commission) == list else \
                            commission['commission']['default']
                        if type(final_commission) == dict:
                            final_commission = final_commission['#text']

                        try:
                            save_to_db(advertiser_id, advertiser_name, program_url, final_commission, tracking_url)
                        except Exception as e:
                            print(advertiser_id, advertiser_name, program_url, final_commission)
                            print(e)
                            continue


def get_tracking_url(advertiser_id):
    url = f"https://link-search.api.cj.com/v2/link-search?website-id=100289292&link-type=banner&advertiser-ids={advertiser_id}"
    payload = {}
    headers = {
        'Authorization': 'Bearer snyw2xshy1vkmp3t0cpgpt1x0'
    }
    response = requests.request("GET", url, headers=headers, data=payload)
    xmldic = xmltodict.parse(response.text)
    json_str_data = json.dumps(xmldic)
    json_data = json.loads(json_str_data)
    try:
        data = json_data['cj-api']['links']['link'][0]['clickUrl']
    except Exception as e:
        print(e)
        print(json_data)
        data = "error"
    return data


def save_to_db(advertiser_id, advertiser_name, program_url, final_commission, tracking_url):
    init_sql = f"""INSERT into advertisers values("{advertiser_id}","{advertiser_name}","{program_url}","{final_commission}", NULL, "{tracking_url}", NULL, NULL, NULL)"""
    # init_sql = f"INSERT into advertisers values('%s','%s','%s','%s', NULL, '%s', NULL, NULL, NULL)" % (
    #     f'{advertiser_id}', f"{advertiser_name}", f'{program_url}', f'{final_commission}', f'{tracking_url}')
    cursor.execute(init_sql)
    db.commit()

    return


def get_data(i):
    url = f"https://advertiser-lookup.api.cj.com/v2/advertiser-lookup?requestor-cid=5653045&advertiser-ids=joined&records-per-page=100&page-number={i}"
    payload = {}
    headers = {
        'Authorization': 'Bearer snyw2xshy1vkmp3t0cpgpt1x0'
    }
    response = requests.request("GET", url, headers=headers, data=payload)
    xmldic = xmltodict.parse(response.text)
    json_str_data = json.dumps(xmldic)
    json_data = json.loads(json_str_data)
    # print(json_data)
    return json_data


def lambda_handler(event, context):
    comissionjun()
