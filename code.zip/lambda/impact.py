import json
import base64
import requests
import pymysql

db = pymysql.connect(host='database-1.c54q9v8pmtt2.us-east-2.rds.amazonaws.com', user='root', password='Nikhilk2kb2', database='ads')
cursor = db.cursor()


bearertoken = "IRXP3qxKFMYh2823107A5Tt8ukuA5qbxf1" + ":" + "LhEBYeTpLdzK.6.atDsrVQn3qUPZLYtP"
# print(bearertoken)
type_encoded = bearertoken.encode("UTF-8")
base_encoded = base64.b64encode(type_encoded)
type_base_encoded = base_encoded.decode("UTF-8")
# print(type_base_encoded)

headers = {'Authorization': f'Basic {type_base_encoded}', 'Accept': 'application/json'}
# print(headers)


def get_data():
    url = "https://api.impact.com/Mediapartners/IRXP3qxKFMYh2823107A5Tt8ukuA5qbxf1/Campaigns?PageSize=1000"
    data = requests.request("GET", url, headers=headers)
    data_json = json.loads(data.text)

    if len(data_json['Campaigns']) > 0:
        for ads in data_json['Campaigns']:
            # print(ads)
            try:
                payout = get_payout(ads['CampaignId'])
            except Exception as e:
                print(e)
                payout = 0

            advertiser_id = ads['AdvertiserId']
            advertiser_name = ads['AdvertiserName']
            program_url = ads['AdvertiserUrl']
            final_commission = payout
            tracking_url = ads['TrackingLink']


            try:
                save_to_db(advertiser_id, advertiser_name, program_url, final_commission, tracking_url)
                print("DONE (~~)")
            except Exception as e:
                print("Not Done ~~~~", advertiser_id, advertiser_name, program_url, final_commission, tracking_url)
                print(e)
                continue


def get_payout(cpid):
    url = f"https://api.impact.com/Mediapartners/IRXP3qxKFMYh2823107A5Tt8ukuA5qbxf1/Campaigns/{cpid}/Contracts/Active"

    data = requests.request("GET", url, headers=headers)

    return json.loads(data.text)['PayoutTermsList'][0]['PayoutPercentage']


def save_to_db(advertiser_id, advertiser_name, program_url, final_commission, tracking_url):
    init_sql = f"""INSERT into advertisers values("{advertiser_id}","{advertiser_name}","{program_url}","{final_commission}", NULL, "{tracking_url}", NULL, NULL, NULL)"""
    cursor.execute(init_sql)
    db.commit()
    return






def lambda_handler(event, context):
    get_data()
