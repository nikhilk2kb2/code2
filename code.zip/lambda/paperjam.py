import json

import pymysql
import requests

db = pymysql.connect(host='database-1.c54q9v8pmtt2.us-east-2.rds.amazonaws.com', user='root', password='Nikhilk2kb2',
                     database='ads')
cursor = db.cursor()


def get_data():
    url = "https://api.pepperjamnetwork.com/20120402/publisher/advertiser?apiKey=e26db1519ee70e630a6fbec9524fcc65e878b96da3786e27e50c47886e3c63b2&format=json&status=joined"
    pj_res = requests.request("GET", url)
    pj_res_stat = pj_res.status_code
    pj_json_res = json.loads(pj_res.text)
    pj_stat = pj_json_res['meta']['status']['code'] if pj_res_stat == 200 else pj_res_stat
    if pj_stat == 200:
        pre_pj_res = pj_json_res['data']
        for data in pre_pj_res:
            ad_id = data['id']
            ad_name = data['name']
            ad_url = data['website']
            ad_commission = data['percentage_payout']
            ad_tracking_url = get_tracking_url(ad_id)

            try:
                save_to_db(ad_id, ad_name, ad_url, ad_commission, ad_tracking_url)
                print("DONE (~~)")
            except Exception as e:
                print("Not Done ~~~~", ad_id, ad_name, ad_url, ad_commission)
                print(e)
                continue

            # print(ad_id, "==", ad_name, "==", ad_url, "==", ad_commission, "==", ad_tracking_url)


def get_tracking_url(ad_id):
    tr_url = f"https://api.pepperjamnetwork.com/20120402/publisher/creative/banner?apiKey=e26db1519ee70e630a6fbec9524fcc65e878b96da3786e27e50c47886e3c63b2&format=json&sid={ad_id}"
    tracking_res = requests.request("GET", tr_url)
    tracking_res_stat = tracking_res.status_code
    tracking_res_json = json.loads(tracking_res.text)
    tracking_stat = tracking_res_json['meta']['status']['code'] if tracking_res_stat == 200 else tracking_res_stat
    if tracking_stat == 200:
        ret_url = tracking_res_json['data'][0]['tracking_url']

    else:
        ret_url = "No url"

    # print("get_tracking_url", tracking_res_json)
    return ret_url


def save_to_db(ad_id, ad_name, ad_url, ad_commission, ad_tracking_url):
    init_sql = f"""INSERT into advertisers values("{ad_id}","{ad_name}","{ad_url}","{ad_commission}", NULL, "{ad_tracking_url}", NULL, NULL, NULL)"""
    cursor.execute(init_sql)
    db.commit()
    pass


def lambda_handler(event, context):
    get_data()
